import { Component, OnInit } from '@angular/core';
import { IProduct } from 'product.model';
import {ProviderAst} from '@angular/compiler';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  providers: [ProductService],
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  title = "Project Manegement";
  imageWidth: number = 75;
  imageMargin: number = 2;
  showImage: boolean = false;


  products : IProduct[]; 
  toggleImage(): void
  {
        this.showImage =!this.showImage;
  }
 
  constructor(private ps:ProductService) { }

  ngOnInit(): void 
  {
   // this.products = this.ps.getProducts();
   this.ps.getProducts().subscribe((data)=>{
     this.products=JSON.parse(JSON.stringify(data));
   })
  }

}
