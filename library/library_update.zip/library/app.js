const express=require('express');
const chalk=require('chalk');
const path=require('path');
//const booksRouter=require('./src/routes/booksRoutes')(nav);

var app=express()


app.set('views','./src/views');
app.set('view engine','ejs');

app.use(express.static(path.join(__dirname,"/public")));
const authorsRouter=express.Router();

app.use('/authors',authorsRouter);

const nav=[
  {link:'/books',title:'Books'},
  {link:'/authors',title:'Authors'},
  {link:'/addBook',title:"Add Book"}
]
const booksRouter=require('./src/routes/booksRoutes')(nav);
const adminRoutes=require('./src/routes/adminRoutes')(nav);


app.use('/books',booksRouter);
app.use('/addBook',adminRoutes);

app.get('/',function(req,res){
  res.render('index',{nav,title:"Library"});
});


app.listen(3000,()=>{
  console.log("App is running sucessfully");
  console.log('Listening to port'+chalk.green('3000'));
});






  authorsRouter.route('/')
  .get((req,res)=>{
    res.render("authors.ejs",
    {nav,title:"Authors"});
  });

  
//app.get('/',function(req,res){
  //res.render('index',{nav:['Books','Authors',],title:'library'});
//});
//app.get('/',function(req,res){
  //res.render('index');
//});

//app.get('/',function(req,res){
//    res.send("Hello from my library app")
//});

//app.get('/',(req,res)=>{
//    res.send('Hello')
//});


