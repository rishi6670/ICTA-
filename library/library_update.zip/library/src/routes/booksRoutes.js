const express=require('express');
const booksRouter=express.Router();
const mongoose=require('mongoose');
const bookdata=require('../model/Bookdata');

function router(nav)
{
    /*var books=[
        {
          title:"War and Peace",
          genre:"Historical Fiction",
          author:"Leo Tolstoy"
        },
        {
          title:"The History of Tom Jones",
          genre:" comic novel ",
          author:"Henry Fielding"
        },
        {
          title:"Pride and Prejudice",
          genre:"Jane Austen",
          author:"Jane Austen"
        },
        {
          title:"Jane Austen",
          genre:"Historical Fiction",
          author:"Leo Tolstoy"
        }
    ];*/
    
    
        booksRouter.route('/')
      .get((req,res)=>{
          bookdata.find()
          .then(function(books){
            res.render("books.ejs",{nav,title:"Books",books});
          });
            
      });
    
      booksRouter.route('/:id')
        .get((req,res)=>{
            const id = req.params.id;
            bookdata.findOne({_id:id})
            .then(function(book){
                res.render("book",
                {
                    nav,
                    title:"Library",
                    book
                })
            });
            
        
        });
        return booksRouter;
        //
}

module.exports = router;