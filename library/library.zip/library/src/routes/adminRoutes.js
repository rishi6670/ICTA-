const express=require('express');
const adminRouter=express.Router();

function router(nav)
{
    adminRouter.route('/')
        .get((req,res)=>{
            res.render("addBook",{nav,title:"Add Book"});
        });
    adminRouter.route('/add')
        .get((req,res)=>{
            res.send("Inserting Books...")
        });
        return adminRouter;
}
module.exports=router;