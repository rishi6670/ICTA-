const express=require('express');
const booksRouter=express.Router();

function router(nav)
{
    var books=[
        {
          title:"War and Peace",
          genre:"Historical Fiction",
          author:"Leo Tolstoy"
        },
        {
          title:"The History of Tom Jones",
          genre:" comic novel ",
          author:"Henry Fielding"
        },
        {
          title:"Pride and Prejudice",
          genre:"Jane Austen",
          author:"Jane Austen"
        },
        {
          title:"Jane Austen",
          genre:"Historical Fiction",
          author:"Leo Tolstoy"
        }
    ];
    
    
        booksRouter.route('/')
      .get((req,res)=>{
        res.render("books.ejs",
        {nav,title:"Books",books});
      });
    
      booksRouter.route('/:id')
        .get((req,res)=>{
            const id = req.params.id;
            res.render("book",
            {
                nav,title:"Library",
                book:books[id]
            }
        );
        });
        return booksRouter;
        //
}

module.exports = router;