const express=require('express');
const fs = require('fs');

var app=express()

app.set('views','./src/views');
app.set('view engine','ejs');

const fileContents = fs.readFileSync('src/json/accounts.json', 'utf8');
 // const data = JSON.parse(fileContents);
const data = [{
    "savings": {
        "unique_name": "savings",
        "nickname": "Savings",
        "account_number": "xxxxx1212"}}];
console.log(data)
app.get('/',function(req,res){
    res.render('index',{data,title:"Library"});
  });

  

  app.listen(5000,()=>{
    console.log("App is running sucessfully");
  });
  